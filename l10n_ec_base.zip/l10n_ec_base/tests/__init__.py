from . import test_account_journal
from . import test_account_payment
from . import test_res_partner
